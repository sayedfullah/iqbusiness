## GETTING STARTED
Install dependencies:
```bash
nmp i
# or
yarn

```
Run the development server:

```bash
npm run dev
# or
yarn dev

```
# BRIEF
-   Build a reusable component to iterate a json data object, injected in simulation page.
-   Iterate the json object and update via a text input/button and apply applicable image.
-   Optional allow for back navigation.
-   Serve the payload.json using JsonServer.
-   Consume json payload from api service (api/index)

# SERVER
- Follow instructions for server usage: https://www.npmjs.com/package/json-server
- Bind data request to api service.

# CLIENT
-   Ensure type safety 
-   Functional components.
-   Use single responsibility principle where applicable
-   Create simple intro component

# VERSION CONTROL 
-  Push branch to github: development or own repository.# iqbusiness

# ASSETS
-   images located in pblic/img/*.jpg
-   json file located in public/json/*.json
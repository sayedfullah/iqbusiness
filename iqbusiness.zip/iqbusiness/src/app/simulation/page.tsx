export default function Home() {
  return (
    <main className="flex h-screen justify-center items-center flex-col">
      <div>
        <h1>Add Simulation</h1>
      </div>
    </main>
  );
}
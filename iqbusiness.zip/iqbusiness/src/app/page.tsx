
export default function Home() {
  return (
    <main className="flex h-screen justify-center items-center flex-col">
      <div>
        <h1>Add Introduction</h1>
      </div>
    </main>
  );
}

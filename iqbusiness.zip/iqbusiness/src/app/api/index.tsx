
const apiGetSimulation = async () => 
{
    return {"data":"some data"};
};